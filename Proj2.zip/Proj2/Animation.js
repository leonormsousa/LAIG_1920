/**
 * Animation
 */
class Animation extends CGFobject {
	constructor(scene){
        super(scene);
    };
    
    update(){};

    apply(){};
}