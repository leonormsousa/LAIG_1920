/**
 * MyAnimator
 */
class MyAnimator extends CGFobject {
	constructor(scene) {
        super(scene);
        this.over=false;
    }

    update(t){
    }

    display(){
    }
}